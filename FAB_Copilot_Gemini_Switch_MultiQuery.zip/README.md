---
title: FAB Copilot MES RAG Assistant
emoji: 🏭
colorFrom: blue
colorTo: indigo
sdk: gradio
sdk_version: 5.23.3
app_file: app.py
pinned: false
license: mit
---

# 半導體製程 FAB Copilot 知識助手

基於 RAG（檢索增強生成）技術的半導體製程知識問答系統。

## 功能
- 💬 對話助手
- 🔬 工程分析模式
- 🔍 知識庫檢索
- ℹ️ 系統說明
- 🔁 Gemini 主模型 + OpenAI fallback
- 🔀 Gemini model 可透過 secret / env 切換

## Hugging Face Secrets
在 Hugging Face Space 的 Settings → Secrets 中加入：

- `GEMINI_API_KEY`
- `OPENAI_API_KEY`

### 可選（若要切換 Gemini 模型）
- `GEMINI_MODEL`

例如：
- `gemini-2.5-flash`
- `gemini-2.0-flash`

## 說明
- 目前預設 `GEMINI_MODEL=gemini-2.5-flash`
- 若不設 `GEMINI_MODEL`，程式會自動使用 `gemini-2.5-flash`
- 若 Gemini quota / rate limit 異常，系統會自動 fallback 到 OpenAI
